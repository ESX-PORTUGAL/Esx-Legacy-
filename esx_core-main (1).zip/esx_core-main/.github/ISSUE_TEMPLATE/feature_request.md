---
name: Feature Request
about: Help us improve esx with your ideas
title: "[Feature Request] - esx_script - Add better configuration"
labels: enhancement
assignees:
  - TheFantomas
  - Gellipapa

---

**Describe the Feature**
A simple description of the new feature.

**Screenshots**
You can also add some screenshots.

**Additional context**
If you want to add something more.
