const translate = new Object();

translate.name = "Naam";
translate.job = "Job";
translate.bank = "Bank";
translate.money = "Cash";
translate.gender = "Gender";
translate.dob = "Geboortedatum";
