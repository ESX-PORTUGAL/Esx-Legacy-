const translate = new Object();

translate.name = "Name";
translate.job = "Beruf";
translate.bank = "Bankguthaben";
translate.money = "Bargeld";
translate.gender = "Geschlecht";
translate.dob = "Geburtsdatum";
