const translate = new Object();

translate.name = "Név";
translate.job = "Munka";
translate.bank = "Bank";
translate.money = "Készpénz";
translate.gender = "Nem";
translate.dob = "Születési idő";
