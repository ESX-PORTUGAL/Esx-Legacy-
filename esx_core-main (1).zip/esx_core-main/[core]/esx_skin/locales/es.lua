Locales["es"] = {
  ["skin_menu"] = "Menú de apariencia",
  ["use_rotate_view"] = "Utiliza ~INPUT_FRONTEND_LS~ y ~INPUT_CHARACTER_WHEEL~ para rotar la vista.",
  ["skin"] = "Cambiar aspecto",
  ["saveskin"] = "Guarda tu aspecto actual",
}
