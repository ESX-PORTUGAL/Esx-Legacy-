Locales["fr"] = {
  ["skin_menu"] = "menu de Skin",
  ["use_rotate_view"] = "utilisez ~INPUT_FRONTEND_LS~ et ~INPUT_CHARACTER_WHEEL~ pour tourner la vue.",
  ["skin"] = "changer de skin",
  ["saveskin"] = "sauvegarder skin dans un fichier",
}
