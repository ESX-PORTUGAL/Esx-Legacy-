Locales["en"] = {
  ["skin_menu"] = "Skin Menu",
  ["use_rotate_view"] = "use ~INPUT_FRONTEND_LS~ and ~INPUT_CHARACTER_WHEEL~ to rotate the view.",
  ["skin"] = "change skin",
  ["saveskin"] = "save skin to a file",
}
