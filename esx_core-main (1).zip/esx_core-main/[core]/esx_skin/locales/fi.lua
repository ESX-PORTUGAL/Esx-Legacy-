Locales["fi"] = {
  ["skin_menu"] = "Ulkonäkö",
  ["use_rotate_view"] = "Paina ~INPUT_FRONTEND_LS~ tai ~INPUT_CHARACTER_WHEEL~ liikutaaksesi kameraa.",
  ["skin"] = "Muokkaa ulkonäköä",
  ["saveskin"] = "Tallenna",
}
