Locales["pl"] = {
  ["skin_menu"] = "menu wyglądu",
  ["use_rotate_view"] = "użyj ~INPUT_FRONTEND_LS~ i ~INPUT_CHARACTER_WHEEL~ aby obrócić ekran.",
  ["skin"] = "zmień wygląd",
  ["saveskin"] = "zapisz wygląd do pliku",
}
