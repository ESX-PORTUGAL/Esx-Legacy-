Locales["da"] = {
    ["skin_menu"] = "Udseende Menu",
    ["use_rotate_view"] = "brug ~INPUT_FRONTEND_LS~ og ~INPUT_CHARACTER_WHEEL~ for at dreje kameraet.",
    ["skin"] = "skift udseende",
    ["saveskin"] = "gem udseende til en fil",
}
