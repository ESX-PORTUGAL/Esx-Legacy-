<h1 align='center'>ESX Legacy</a></h1>
<p align='center'><a href='https://discord.esx-framework.org/'>Discord</a> - <a href='https://esx-framework.org/'>Website</a> - <a href='https://documentation.esx-framework.org/legacy/installation'>Documentation</a></b></h5>

<p align='center'>Want more resources? You can browse the <a href="https://forum.cfx.re/tag/esx">Cfx.re Releases board</a> for more!
<p align='center'><b>ESX is the leading framework, trusted by over 12,000 communities to provide the highest quality roleplay servers on FiveM</b></p>

<hr>

### 💗 Supporters

Interested in helping us? [Take a look at our patreon](https://www.patreon.com/esx "Take a look at our patreon")

| We would like to sincerely thank the following donors who helped fund the development of ESX.  |
| ------------ |
| Mohamad Buhamad - Michael Hein - RoadToSix - Montree Narathong  |
| Saydoon - Muhannad alyamani - iSentrie - Wecity - Samuel Nicol |
| Kyle McShea - Artin - Mathias Christoffersen - Jaylan Yilmaz - Callum |
| CONGRESS KW - Michael Hein - Smery sitbon - daZepelin - CMF Community |
------


<br>
<table><tr><td><h4 align='center'>Legal Notices</h4></tr></td>
<tr><td>
ESX Core (ESX-legacy)

 Copyright (C) 2015-2023 [ESX-Framework](https://github.com/esx-framework)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.


This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.


You should have received a copy of the GNU General Public License
along with this program.
If not, see <https://www.gnu.org/licenses/>
</td></tr></table>

Powered by [Oxygenserv](https://www.oxygenserv.com/en/)
